Context:
In our case, the rover is'nt finished; we wanted to confirm if the actual rover is compliant at the safety level (given that we did'nt finish all the design) and that we are not going in the wrong way.



Some indication of how to understand this review:
1. I suggest you to look at the electrical system schematic first so you can have an overview of the rover (//System/ROVUS_ELECTRICAL_SCHEM_REV0.png).
2. You can have access to all the specsheets of the equipement that we choosed for our design in the folder //specsheets.
3. Extra documentation is given so you can evaluate our design.
4. Finally, the documentation of the case, were all of the devices will be in, is given.

If you have any question for the design, you can contact: edouard.villemure@usherbrooke.ca

