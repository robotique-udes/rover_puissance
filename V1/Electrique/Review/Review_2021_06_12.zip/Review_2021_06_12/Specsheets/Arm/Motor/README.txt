The sketch in this section is just to show where each motor is supposed to be on the arm.
All number of the folder is associated with a number in the sketch.